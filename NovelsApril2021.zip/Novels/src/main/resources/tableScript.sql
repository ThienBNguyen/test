create database novelsdb;
use novelsdb;

create table novel (
  id integer(4) primary key auto_increment,
  title varchar(200) not null,
  year integer(4),
  auth_id integer(4) references author(id)
);

create table author (
	id integer(4) primary key,
	name varchar(100) not null
);

