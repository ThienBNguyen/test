package com.infy.dto;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;


public class AuthorDTO {
	@NotNull
	@Max(9999)
	private Integer id;
	
	@NotNull
	@Pattern(regexp = "[A-Za-z][A-Za-z ]*")
	private String name;
	
	@Valid
	private List<NovelDTO> novelDTOs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<NovelDTO> getNovelDTOs() {
		return novelDTOs;
	}

	public void setNovelDTOs(List<NovelDTO> novelDTOs) {
		this.novelDTOs = novelDTOs;
	}

	/// Since the fields are private, the only way outside classes can find fields is through getter setters
	
	
}
